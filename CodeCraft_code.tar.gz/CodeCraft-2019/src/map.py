import sys
import os
import copy
import dijkstra
import dispatcher

class Car:
    def __init__(self, id, start, to, speed, planTime, graph):
        self.id = id
        self.start = start
        self.to = to
        self.speed = speed
        self.planTime = planTime
        self.graph = graph
        
        self.state = None
        # self.state_update_time = None
        
        dijk = dijkstra.Dijkstra(graph)
        dijk.run(start, to)
        
        self.shorest_path_cross_index = dijk.cross_path
        self.shorest_path_road = dijk.road_path

        self.current_cross_start = start
        self.current_cross_to = self.shorest_path_cross_index[1]
        self.next_cross = self.shorest_path_cross_index[2]
        self.current_road = graph.adjacent_matrix[self.current_cross_start][self.current_cross_to]
        self.current_channel = dispatcher.get_channel_next_road(self.current_road)
        
        self.road_postion_to_direction = self.get_road_to_direction_table()

        next_road = graph.adjacent_matrix[self.current_cross_to][self.next_cross]
        self.direction = self.get_direction_by_road(self.current_road, next_road)
        obstacle_car = dispatcher.get_first_obstacle_front(self.current_channel, -1, self.current_road.length)
        
        self.current_position = 0
        if obstacle_car is not None:
            self.current_position = obstacle_car.current_position - 1

    def wait_car(self):
        self.state = 'wait'

    def get_road_to_direction_table(self):
        road_postion_to_direction = [4 * [None] for i in range(4)]
        road_postion_to_direction[0][1] = 'left'
        road_postion_to_direction[0][2] = 'direct'
        road_postion_to_direction[0][3] = 'right'
        
        road_postion_to_direction[1][0] = 'right'
        road_postion_to_direction[1][2] = 'left'
        road_postion_to_direction[1][3] = 'direct'
        
        road_postion_to_direction[2][0] = 'direct'
        road_postion_to_direction[2][1] = 'right'
        road_postion_to_direction[2][3] = 'left'
        
        road_postion_to_direction[3][0] = 'left'
        road_postion_to_direction[3][1] = 'direct'
        road_postion_to_direction[3][2] = 'right'
        return road_postion_to_direction

    # 根据道路获取车辆方向
    def get_direction_by_road(self, road_start, road_to):
        if road_to is None:
            return None
        cross_i = -1
        if road_start.start == road_to.start or road_start.start == road_to.to:
            cross_i = road_start.start
        if road_start.to == road_to.start or road_start.to == road_to.to:
            cross_i = road_start.to
        if cross_i != -1:
            roads_in_cross = self.graph.cross_data[cross_i]
            road_start_i = roads_in_cross.index(road_start.id)
            road_to_i = roads_in_cross.index(road_to.id)
            return self.road_postion_to_direction[road_start_i][road_to_i]
        return None

    # 获取车辆的方向优先级
    def get_direction_priority(self):
        if self.direction is None:
            return None
        direct_priority_list = ['right', 'left', 'direct']
        return direct_priority_list.index(self.direction)
        
class Cross:
    def __init__(self, id, roadNId, roadEId, roadSId, roadWId):
        self.id = id
        self.roadNId = roadNId
        self.roadEId = roadEId
        self.roadSId = roadSId
        self.roadWId = roadWId


class Road:
    def __init__(self, id, length, speed, channel, start, to, isDuplex):
        self.id = id
        self.length = length
        self.speed = speed
        self.channel = channel
        self.start = start
        self.to = to
        self.isDuplex = isDuplex
        self.cost = sys.maxsize
        self.direction = None
        self.channel_list = [self.length * [None] for i in range(self.channel)]
        
class Graph:

    def __init__(self, car_data_path, road_data_path, cross_data_path):
        
        self.adjacent_matrix = []
        self.car_data, self.road_data, self.cross_data = self.load_data(car_data_path, road_data_path, cross_data_path)
        self.cross_id_list = [i[0] for i in self.cross_data]
        self.num_cars = len(self.car_data)
        self.num_crosses = len(self.cross_data)
        self.num_roads = len(self.road_data)

        self.init_graph()

        # test car data
        self.test_data()
    
    def test_data(self):
        # self.show_graph()
        car1 = Car(1, 0, 9, 2, 1, self)
        car1.current_cross_start = 0
        car1.current_cross_to = 1
        car1.current_road = self.adjacent_matrix[car1.current_cross_start][car1.current_cross_to]
        car1.current_channel = car1.current_road.channel_list[0]
        car1.current_position = 1
        car1.next_cross = 2
        car1.direction = 'direct'
        car1.current_channel[car1.current_position] = car1

        car2 = Car(2, 0, 9, 6, 1, self)
        car2.current_cross_start = 0
        car2.current_cross_to = 1
        car2.current_road = self.adjacent_matrix[car2.current_cross_start][car2.current_cross_to]
        car2.current_channel = car2.current_road.channel_list[0]
        car2.current_position = 4
        car2.next_cross = 2
        car2.direction = 'direct'
        car2.current_channel[car2.current_position] = car2
        
        car3 = Car(3, 0, 7, 6, 1, self)
        car3.current_cross_start = 0
        car3.current_cross_to = 1
        car3.current_road = self.adjacent_matrix[car3.current_cross_start][car3.current_cross_to]
        car3.current_channel = car3.current_road.channel_list[0]
        car3.current_position = 7
        car3.next_cross = 7
        car3.direction = 'right'
        car3.current_channel[car3.current_position] = car3

        car4 = Car(4, 2, 7, 6, 1, self)
        car4.current_cross_start = 2
        car4.current_cross_to = 1
        car4.current_road = self.adjacent_matrix[car4.current_cross_start][car4.current_cross_to]
        car4.current_channel = car4.current_road.channel_list[0]
        car4.current_position = 7
        car4.next_cross = 7
        car4.direction = 'left'
        car4.current_channel[car4.current_position] = car4


    def load_data(self, car_data_path, road_data_path, cross_data_path):
        car_data = []
        road_data = []
        cross_data = []
        for file_name in ['car', 'road', 'cross']:
            data_file_path = eval(file_name+'_data_path')
            lines = open(data_file_path).read().splitlines()[1:]
            for line in lines:
                spts = line[1:-1].split(',')
                tmp = [int(i) for i in spts]
                eval(file_name + "_data").append(tmp)
        return car_data, road_data, cross_data

    # 初始化图，读取数据填充二维邻接矩阵 graph_matrix
    def init_graph(self):
        # 邻接矩阵初始化为 大小为路口数*路口数 值为None的二维数组
        self.adjacent_matrix = [self.num_crosses * [None]
                                for i in range(self.num_crosses)]

        for road_item in self.road_data:
            road_id, length, speed, channel= road_item[0], road_item[1], road_item[2], road_item[3]

            # 路口从1开始，而邻接矩阵从0开始，故 start 和 to 减1
            start, to, isDuplex = road_item[4] - 1, road_item[5] - 1, road_item[6]
            road = Road(road_id, length, speed,
                        channel, start, to, isDuplex)
            road.cost = length / speed
            self.adjacent_matrix[start][to] = road
            if isDuplex == 1:  # 双向车道，在图中为双向
                self.adjacent_matrix[start][to].direction = 'forward'
                self.adjacent_matrix[to][start] = copy.deepcopy(road)
                self.adjacent_matrix[to][start].direction = 'reverse'
                self.adjacent_matrix[to][start].start = to
                self.adjacent_matrix[to][start].to = start
    
    def show_graph(self):
        # 记录每个路口有多少条路
        num_roads_in_cross = []
        for line in self.adjacent_matrix:
            # 将邻接矩阵的一行映射成 0 或 cost（方便查看），0表示不连通
            temp = []
            count = 0
            for item in line:
                if item is None:
                    temp.append(0)
                else:
                    temp.append(item.cost)
                    count += 1
            num_roads_in_cross.append(count)
            print(temp)
        # print(num_roads_in_cross)
        